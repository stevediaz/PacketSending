import socket
import time

ipAddress = '127.0.0.1'
port = 8000
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

clientSocket.settimeout(1)
ottArray = []
rttArray = []
try:
	for x in range(1,11):
                #start time
		sendTime = time.time()
		message = 'Ping message number ' + str(x) + " " + time.ctime(sendTime)
		try:
			cReceiveTime = time.time()	
			sent = clientSocket.sendto(message.encode(),(ipAddress, port))
			print ("Sent " + message)

			data, server = clientSocket.recvfrom(2048)
			realdata = data.decode('ascii')

			print ("Received " + realdata)
			endTime = time.time()
			RTT = endTime - sendTime
			OTT = cReceiveTime - sendTime
			print ("RTT (OTT): %f (%f) seconds" %(RTT,OTT))
			ottArray.append(OTT)
			rttArray.append(RTT)	
		except socket.timeout:
			print ("Ping message number " + str(x) + " Requested Time Out\n")
	ottMin = min(ottArray)
	ottMax = max(ottArray)
	ottAvrg = sum(ottArray)/len(ottArray)
	print ("Minimum OTT --- Maximum OTT --- Average OTT:  %f --- %f --- %f" %(ottMin, ottMax, ottAvrg))

	rttMin = min(rttArray)
	rttMax = max(rttArray)
	rttAvrg = sum(rttArray)/len(rttArray)
	print ("Miniumum RTT --- Maximum RTT --- Average RTT: %f --- %f --- %f" %(rttMin, rttMax, rttAvrg))
finally:
	clientSocket.close()

