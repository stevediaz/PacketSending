How to run my ClientUDP.py & ClientUDP.py*
First, Run the following command in a terminal or command line:
In terminal you can easily just run it as:
	python ClientUDP.py & ClientUDP.py
In Command line:
C:\(YourPythonDirectory)\python.exe   C:\(YourPythonDirectory)\ClientUDP.py
C:\(YourPythonDirectory)\python.exe   C:\(YourPythonDirectory)\ServerUDP.py

Run the Server First, then run the client, everything should work with the ServerUDP running at all times and the client can be run multiple times!
