import random
import socket

ipAddress = '127.0.0.1'
portNum = 8000

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

serverSocket.bind((ipAddress,portNum))
print ("Pinging %s %i " %(ipAddress, portNum)) 

while 1:
        random1 = random.randint(0,10)
        message, addr = serverSocket.recvfrom(2048)
        message = message.upper()

        if random1 < 4:
                continue
	
        serverSocket.sendto(message, addr)

